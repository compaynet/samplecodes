jQuery(document).ready(function( $ ) {
    $('#iban').attr('readonly', 'readonly');
    $('#paymentMethod').change(function () {
        if($('#paymentMethod').val() == 'ppro.sepadirectdebit')
        {
            $('#iban').removeAttr('readonly', '');
            $('#iban').attr('required', '');
        }else{
            $('#iban').val('');
            $('#iban').attr('readonly', 'readonly');
        }
    })
});