<?php
	/* Gateway class
    /**
	 */
	class WC_Compaynet_Direct extends WC_Payment_Gateway {

		private $gateway 		= 'compaynet-bank-transfer';
		private $test_ac 		= 111999;
		private $secret			= 'Man37HTX3qNxQfAS';
		private $mms_url 		= 'https://csmms.compaynet.com';
		private $gateway_direct_url 	= 'https://csgateway.compaynet.com/direct/';
		public  $gateway_url 	= 'none';

		public function __construct() {
			$this->id     				= $this->gateway;
			$this->method_title   		= __(ucwords($this->gateway) , 'woocommerce_compaynet-bank-transfer');
			$this->method_description 	= __(ucwords($this->gateway) . ' direct works by sending the user to ' . ucwords($this->gateway) . ' to enter their payment information', 'woocommerce_compaynet-bank-transfer');
			$this->icon     			= str_replace('/classes', '/', plugins_url( '/', __FILE__ )) . '/img/logo.png';
			$this->has_fields    		= false;

			$this->init_form_fields();

			$this->init_settings();

			// Get setting values
			$this->enabled       		= isset( $this->settings['enabled'] ) ? $this->settings['enabled'] : 'no';
			$this->title        		= isset( $this->settings['title'] ) ? $this->settings['title'] : 'Bank Transfer via COMPAYNET';
			$this->description       	= isset( $this->settings['description'] ) ? $this->settings['description'] : 'Pay via Bank transfer with COMPAYNET processing.';
			$this->gateway 				= isset( $this->settings['gateway'] ) ? $this->settings['gateway'] : 'compaynet-bank-transfer';
			$this->type 				= isset( $this->settings['type'] ) ? $this->settings['type'] : 'direct';

			$this->xref                 = '';
			if (isset($this->settings['type'])) {
				$this->gateway_url = $this->gateway_direct_url;
			} else {
				$this->gateway_url = $gateway_direct_url;
			}

			// Hooks
			/* 1.6.6 */
			add_action( 'woocommerce_update_options_payment_gateways', array( $this, 'process_admin_options' ) );

			/* 2.0.0 */
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
			add_action('woocommerce_receipt_compaynet-bank-transfer', array($this, 'receipt_page'));
			add_action('woocommerce_api_wc_compaynet_direct', array($this, 'process_response'));
            /*add custom_assets*/

        }

		/**
		 * Initialise Gateway Settings
		 */
		function init_form_fields() {
            add_action('wp_enqueue_scripts',array( $this, 'this_custom_assets' ));
			$this->form_fields = array(
				'enabled'		=> array(
					'title'   		=> __( 'Enable/Disable', 'woocommerce_compaynet-bank-transfer' ),
					'label'   		=> __( 'Enable COMPAYNET Bank Transfer', 'woocommerce_compaynet-bank-transfer' ),
					'type'    		=> 'checkbox',
					'description'  	=> '',
					'default'   	=> 'no'
				),

				'title'			=> array(
					'title'   		=> __( 'Title', 'woocommerce_compaynet-bank-transfer' ),
					'type'    		=> 'text',
					'description'  	=> __( 'This controls the title which the user sees during checkout.', 'woocommerce_compaynet-bank-transfer' ),
					'default'   	=> __( strtoupper(ucwords($this->gateway)), 'woocommerce_compaynet-bank-transfer' )
				),

				'type'			=> array(
					'title'   		=> __( 'Type of integration', 'woocommerce_compaynet-bank-transfer' ),
					'type'    		=> 'text',
					'description'  	=> __( 'This controls method of integration.', 'woocommerce_compaynet-bank-transfer' ),
					'default'   	=> 'direct'
				),

				'description'	=> array(
					'title'   		=> __( 'Description', 'woocommerce_compaynet-bank-transfer' ),
					'type'    		=> 'textarea',
					'description'  	=> __( 'This controls the description which the user sees during checkout.', 'woocommerce_compaynet-bank-transfer' ),
					'default'   	=> 'Pay securely via Bank Transfer with ' . ucwords($this->gateway)
				),

				'merchantID'	=> array(
					'title'   		=> __( 'Merchant ID', 'woocommerce_compaynet-bank-transfer' ),
					'type'    		=> 'text',
					'description'  	=> __( 'Please enter your ' . ucwords($this->gateway) . ' merchant ID', 'woocommerce_compaynet-bank-transfer' ),
					'default'   	=> $this->test_ac
				),

				'signature'	=> array(
					'title'   		=> __( 'Signature Key', 'woocommerce_compaynet-bank-transfer' ),
					'type'    		=> 'text',
					'description'  	=> __( 'Please enter the signature key for the merchant account. This can be changed in the <a href="'.$this->mms_url.'" target="_blank">MMS</a>', 'woocommerce_compaynet-bank-transfer' ),
					'default'   	=> $this->secret
				),

				'formResponsive' => array(
					'title'   		=> __( 'Responsive form', 'woocommerce_compaynet-bank-transfer' ),
					'type'    		=> 'select',
					'options'       => array(
						'Y'    => 'Yes',
						'N'    => 'No'
					),
				'description'  	=> __( 'This controls whether the payment form is responsive.', 'woocommerce_compaynet-bank-transfer' ),
				'default'   	=> 'No'
				),

				'customForm' => array(
					'title' => __('Custom form', 'woocommerce_compaynet-bank-transfer'),
					'type' => 'text',
					'description' => __('Allows the use of custom forms', 'woocommerce_compaynet-bank-transfer'),
					'default' => $this->gateway_direct_url
				),

				'countryCode'	=> array(
					'title'   		=> __( 'Country Code', 'woocommerce_compaynet-bank-transfer' ),
					'type'    		=> 'text',
					'description'  	=> __( 'Please enter your 3 digit <a href="http://en.wikipedia.org/wiki/ISO_3166-1" target="_blank">ISO country code</a>', 'woocommerce_compaynet-bank-transfer' ),
					'default'   	=> '826'
				),

			);

		}

		/**
		 * Generate the form buton
		 */

		public function generate_compaynet_form($order_id) {
		    if ( $this->type == 'direct' ) {
				echo $this->generate_compaynet_direct_form($order_id);
			} else {
				return null;
			}
		}

		/**
		 * Direct form step 1
		 */
		public function generate_compaynet_direct_form($order_id) {

			global $woocommerce;
            add_action('wp_enqueue_scripts',array( $this, 'this_custom_assets' ));
            $order 		= new WC_Order( $order_id );
			$countries	= new WC_Countries();
			$amount 	= $order->get_total() * 100;
//			$redirect 	= add_query_arg('wc-api', 'WC_Compaynet_Direct', home_url( '/' ));
			$redirect 	= add_query_arg(
			    array(
			        'wc-api' => 'WC_Compaynet_Direct',
			        'order_id' => $order_id

                ), home_url( '/' ));
			// $callback 	= add_query_arg('wc-api', 'WC_Compaynet_Direct_Callback', home_url( '/' ));

			$billing_address  = $order->billing_address_1 . "\n";
			if (isset($order->billing_address_2) && !empty($order->billing_address_2)) {
				$billing_address .= $order->billing_address_2 . "\n";
			}
			$billing_address .= $order->billing_city . "\n";
			$billing_address .= $order->billing_state;

            // Fields for hash
			$fields = array(
                'paymentMethod' => array(
                    "name" => "Bank Transfer Systems",
                    'type'          => 'select',
                    'label'         => __('select Bank transfer systems'),
                    'required'    => true,
                    'options'     => array(
                        'ppro.mybank' => __('MyBank'),
                        'ppro.sepadirectdebit' => __('SEPA'),
                        'ppro.directpay' => __('SoFort'),
                        'ppro.trustly' => __('Trustly')
                    )
                ),
				"iban" => array(
					"name" => "IBAN",
					"value" => "",
                    'type' => 'text'
				),
				"customerName" => array(
					"name" => "Name",
					"value" => "{$order->billing_first_name} {$order->billing_last_name}",
                    'type' => 'text',
					"required" => "required"
				),
				"customerEmail" => array(
					"name" => "Email",
					"value" => $order->billing_email,
                    'type' => 'text',
					"required" => "required"
				),
				"customerPhone" => array(
					"name" => "Phone",
					"value" => $order->billing_phone,
                    'type' => 'text',
					"required" => ""
				),
				"customerAddress" => array(
					"name" => "Address",
					"value" => $billing_address,
                    'type' => 'text',
					"required" => "required"
				),
				"customerPostCode" => array(
					"name" => "Post Code",
					"value" => $order->billing_postcode,
                    'type' => 'text',
					"required" => "required"
				),
				"checkoutRedirectURL" => array(
					"value" => $redirect,
                    'type' => 'hidden',
					"required" => "required"
				)
			);

			$form = '<form action="' . '//' . $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] . '&step=2" method="post" id="' . $this->gateway . '_payment_form">';

			foreach ( $fields as $key => $value )
			{
			    $form .= '<div class="form-group">';
				if($value['name']) $form .= '<label class="card-label label-'.$key.'">' . $value['name'] . '</label>';
				if($value['type'] == 'select')
				{
                    $form .= '<select type="'.$value['type'].'" class="form-control field-'. $key .'" name="' . $key . '" id="' . $key . '" ' . $value['required'] . ' >';
                    foreach ($value['options'] as $key => $value)
                    {
                        $form .= '<option value="'.$key.'">'.$value.'</option>';
                    }
                    $form .= '</select>';
				}else{
                    $form .= '<input type="'.$value['type'].'" class="form-control field-'. $key .'" name="' . $key . '" id="' . $key . '" value="' . $value['value'] . '" ' . $value['required'] . ' />';
                }
                $form .= '</div>';
			}
			$form .= '<button type="submit" class="btn btn-primary">'.__('Pay securely via ' . ucwords( $this->gateway ), 'woocommerce_compaynet-bank-transfer').'</button>&nbsp;';
			$form .= '<a class="btn btn-secondary" href="'.$order->get_cancel_order_url().'">'.__('Cancel order', 'woocommerce_compaynet-bank-transfer').'</a>';
			$form .= '</form>';

			return $form;

		}

		/**
		 * Direct form step 2
		 */
		public function generate_compaynet_direct_form_step2( $order_id, $request = array() ) {

			global $woocommerce;

			$order 		= new WC_Order( $order_id );
			$countries	= new WC_Countries();
			$amount 	= $order->get_total() * 100;

            $getCurrency = new WC_Compaynet_Direct();
            $currency_numeric_code = $getCurrency->get_country_code($order->get_order_currency(), 'ISO4217-currency_alphabetic_code', 'ISO4217-currency_numeric_code');
            $alpha_3 = $getCurrency->get_country_code($order->get_billing_country(), 'ISO3166-1-Alpha-2', 'ISO3166-1-Alpha-3');
			// Fields for hash
			$req = array(
				"merchantID" => $this->settings['merchantID'],
				"action" => "SALE",
				"type" => 1,
				"paymentMethod" => $_REQUEST['paymentMethod'],
				"transactionUnique" => $order->order_key . '-' . time(),
				"currencyCode" => $currency_numeric_code,
				"amount" => $amount,
				"orderRef" => $order->id,
                "checkoutRedirectURL" 	=> $_REQUEST['checkoutRedirectURL'],
				"customerName" => $_REQUEST['customerName'],
				"customerEmail" => $_REQUEST['customerEmail'],
				"customerPhone" => $_REQUEST['customerPhone'],
				"customerAddress" => $_REQUEST['customerAddress'],
                "countryCode" => $alpha_3,
				"customerPostCode" => $_REQUEST['customerPostCode']
			);
			if($_REQUEST['paymentMethod']) $req['checkoutOptions']['iban'] = $_REQUEST['iban'];
            $req['checkoutOptions']['consumerref'] = $req['transactionUnique'];
			// Add Signature field to the end of the request.
			$req['signature'] = $this->createSignature($req, $this->settings['signature']);


			$ch = curl_init($this->gateway_url);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($req));
			curl_setopt($ch, CURLOPT_HEADER, false);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			parse_str(curl_exec($ch), $res);
			curl_close($ch);

			if ($res['responseCode'] == 65826)
			{
                wc_setcookie("xref", $res['xref'], time()+3600);
			    if($_REQUEST['paymentMethod']=='ppro.sepadirectdebit')
			    {
                    $iframe  = '<div class="col-12">';
                    $iframe .= '<iframe width="100%" height="600px" name="iframe_checkoutURL" id="iframe_checkoutURL" src="'.$res['checkoutURL'].'"></iframe>';
                    $iframe .= '<a class="btn btn-secondary" href="'.$res['checkoutRedirectURL'].'">'.__('View order', 'woocommerce_compaynet-bank-transfer').'</a>';
                    $iframe .= '</div>';
                    echo $iframe;
			    }else
                    {
                    wp_redirect($res['checkoutURL']);

                }


			} elseif (isset($res['signature'])) {
				$orderNotes  =  "\r\nResponse Code : {$res['responseCode']}\r\n";
				$orderNotes .=  "Message : ". htmlentities($res['responseMessage']) . "\r\n";
				$orderNotes .=  "Amount Received : " . number_format($res['amount'] / 100, 2, '.', ',') . "\r\n";
				$orderNotes .=  "Unique Transaction Code : {$res['transactionUnique']}";

				$return_signature = $res['signature'];

				// Remove the signature as this isn't hashed in the return
				unset($res['signature']);

				// The returned hash will always be SHA512
				if ($return_signature == $this->createSignature($res, $this->settings['signature'])) {

					echo "<p>Signature Check OK!</p>" . PHP_EOL;

					if ($res['responseCode'] === "0") {

						$order->add_order_note( __(ucwords( $this->gateway ).' payment completed.' . $orderNotes, 'woocommerce_compaynet-bank-transfer') );
						$order->payment_complete();
						echo "<p>Thank you for your payment</p>" . PHP_EOL;
						exit;
					} else {
						echo "<p>Failed to take payment: " . htmlentities($res['responseMessage']) . "</p>" . PHP_EOL;
					}
				} else {

					die("Sorry, the signature check failed");

				}
			} else {

				if ($res['responseCode'] === "0") {

					$order->add_order_note( __(ucwords( $this->gateway ).' payment completed.' . $orderNotes, 'woocommerce_compaynet-bank-transfer') );
					$order->payment_complete();
					echo "<p>Thank you for your payment</p>";
					exit;
				} else {

					echo "<p>Failed to take payment: " . htmlentities($res['responseMessage']) . "</p>" . PHP_EOL;

				}
			}

			return $form;

		}

		/**
		 * Function to generate a signature
		 */

		function createSignature(array $data, $key) {

			if (!$key || !is_string($key) || $key === '' || !$data || !is_array($data)) {
					return null;
			}

			ksort($data);

			// Create the URL encoded signature string
			$ret = http_build_query($data, '', '&');

			// Normalise all line endings (CRNL|NLCR|NL|CR) to just NL (%0A)
			$ret = preg_replace('/%0D%0A|%0A%0D|%0A|%0D/i', '%0A', $ret);

			// Hash the signature string and the key together
			return hash('SHA512', $ret . $key);

		}



		/**
		 * Process the payment and return the result
		 */
		function process_payment( $order_id ) {

			$order = new WC_Order($order_id);

			return array(
				'result'    => 'success',
				'redirect'	=> $order->get_checkout_payment_url( true )
			);

		}


		/**
		 * receipt_page
		 */
		function receipt_page( $order ) {
			if (isset($_REQUEST['step']) && (int)$_REQUEST['step'] === 2) {
				echo $this->generate_compaynet_direct_form_step2($order, $_REQUEST);
			} else {
				echo '<p>' . __('Thank you for your order, please click the button below to pay with ' . ucwords($this->gateway) . '.', 'woocommerce_compaynet-bank-transfer') . '</p>';
				echo $this->generate_compaynet_form($order);
			}
		}



		/**
		 * Check for COMPAYNET Response
		 */
		function process_response() {

			global $woocommerce;
            $response = (count($_GET) > 0) ? $_GET : $_POST;
            $order_id = (isset($response['order_id'])) ? $response['order_id'] : $response['orderRef'];
            $order	= new WC_Order((int) $order_id);
			if (isset($response['responseCode'])) {

				if ($order->status == 'completed' || $order->status == 'accepted') {

				} else {

					$orderNotes  =  "\r\nResponse Code : {$response['responseCode']}\r\n";
					$orderNotes .=  "Message : {$VPMessage}\r\n";
					$orderNotes .=  "Amount Received : " . number_format($response['amount'] / 100, 2, '.', ',') . "\r\n";
					$orderNotes .=  "Unique Transaction Code : {$response['transactionUnique']}";

                    if ($response['responseCode'] === '0') {

						$order->add_order_note( __(ucwords( $this->gateway ).' payment completed.' . $orderNotes, 'woocommerce_compaynet-bank-transfer') );
						$order->payment_complete();

						wp_safe_redirect( $this->get_return_url( $order ) );
						exit;

					} else {

						$message = __('Payment error: ', 'woothemes') . $response['responseMessage'];

						if (method_exists($woocommerce, add_error)) {
							$woocommerce->add_error($message);
						} else {
							wc_add_notice($message, $notice_type = 'error');
						}

						$order->add_order_note( __(ucwords( $this->gateway ).' payment failed.' . $orderNotes, 'woocommerce_compaynet-bank-transfer') );
						wp_safe_redirect( $order->get_cancel_order_url( $order ) );
						exit;

					}

				}

			} else {

                $request = array();
                $request['merchantID'] = $this->settings['merchantID'];
                $request['action'] = "QUERY";
                $request['xref'] = $_COOKIE['xref'];
                $request['signature'] = $this->createSignature($request, $this->settings['signature']);
                $ch = curl_init($this->gateway_url);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($request));
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                parse_str(curl_exec($ch), $response);
                curl_close($ch);
                if ($response['responseCode'] === '0') {

                    $orderNotes  =  "\r\nAmount Received : " . number_format($response['amount'] / 100, 2, '.', ',') . "\r\n";
                    $orderNotes .=  "Unique Transaction Code : {$response['transactionUnique']}\r\n";
                    $orderNotes .=  "XREF : {$response['xref']}";
                    $order->add_order_note( __(ucwords( $this->gateway ).' payment completed.' . $orderNotes, 'woocommerce_compaynet-bank-transfer') );
                    $order->payment_complete();
                    wp_safe_redirect( $this->get_return_url( $order ) );
                    exit;

                } else {

                    $message = __('Payment error: ', 'woothemes') . $response['responseMessage'];

                    if (method_exists($woocommerce, add_error)) {
                        $woocommerce->add_error($message);
                    } else {
                        wc_add_notice($message, $notice_type = 'error');
                    }
                    $orderNotes  =  "\r\nResponse Code : {$response['responseCode']}\r\n";
                    $orderNotes .=  "Message : ". htmlentities($res['responseMessage']);
                    $order->add_order_note( __(ucwords( $this->gateway ).' payment failed.' . $orderNotes, 'woocommerce_compaynet-bank-transfer') );
                    wp_safe_redirect( $order->get_cancel_order_url( $order ) );
                    exit;

                }
			}

		}

		/*
		 * get country code
		 * */
		function get_country_code($to_search='', $search='', $to_value='')
        {
           $currency = file_get_contents(plugins_url( "/", __FILE__ ). "codes-all_json.json");
           $json_data = json_decode($currency, true);
           $get_value = '';
           foreach ($json_data as $key => $value)
           {
                if($value["$search"] == $to_search)
                {
                    $get_value = $value["$to_value"];
                }

           }
           return $get_value;
        }


        /*
         *  load custom assets*/
        function this_custom_assets()
        {
            wp_enqueue_script( 'wc-compaynet-bank-transfer', plugins_url('assets/js/custom-script.js', dirname(__FILE__)), array('jquery'), WC()->version, true );
            wp_enqueue_style( 'wc-compaynet-bank-transfer', plugins_url('assets/css/custom.css', dirname(__FILE__)), array(), '1.1', 'all');
        }

	}
