from setuptools import setup

setup(
    name='compaynet',
    version='0.0.1',
    description=("A software development kit for the Compaynet payment gateway."),
    # license='GPLv2',
    install_requires=['requests'],
    packages=['compaynet'],
)
