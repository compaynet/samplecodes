#!/usr/bin/env python

from __future__ import print_function
from compaynet.payment import Gateway
from unittest import TestCase
from urllib import urlencode

class GatewayTestCase(TestCase):

    """Test cases for Gateway class.
    """

    def setUp(self):
        self.host = 'https://csgateway.compaynet.com/direct/'
        self.id = '108896'
        self.secret = 'Excuse8Boil48Fleet'
        self.compaynet = Gateway(self.host, self.id, self.secret)
        self.request = {
            'merchantID': self.id,
            'action': 'SALE',
            'amount': 1000,
            'cardCVV': 356,
            'cardExpiryMonth': 12,
            'cardExpiryYear': 15,
            'cardNumber': '4929421234600821',
            'countryCode': 826, # GB
            'currencyCode': 826, # GBP
            'customerAddress': '6347 Test Card Street',
            'customerName': 'John Smith',
            'customerPhone': '+44 (0) 8450099575',
            'customerPostCode': '17T ST8',
            'orderRef': 'Test purchase',
            'type': 1 # E-commerce
        }
        self.signature = self.compaynet.sign(self.request, self.secret, partial=True)

    def test_direct_request(self):

        request = self.compaynet.prepareRequest(self.request)

        response = self.compaynet.directRequest(request)

        self.assertEqual(int(response['responseCode']), Gateway.RC_SUCCESS)
        self.assertEqual(int(response['amountReceived']), int(request['amount']))
        self.assertEqual(response['state'], 'captured')

    def test_hosted_request(self):

        request = self.compaynet.prepareRequest(self.request)

        response = self.compaynet.hostedRequest(request)

        expect = [
            '<form method="post"  action="', self.host, '">\n',
            '<input type="hidden" name="action" value="', self.request['action'], '" />\n',
            '<input type="hidden" name="amount" value="', self.request['amount'], '" />\n',
            '<input type="hidden" name="cardCVV" value="', self.request['cardCVV'], '" />\n',
            '<input type="hidden" name="cardExpiryMonth" value="', self.request['cardExpiryMonth'], '" />\n',
            '<input type="hidden" name="cardExpiryYear" value="', self.request['cardExpiryYear'], '" />\n',
            '<input type="hidden" name="cardNumber" value="', self.request['cardNumber'],  '" />\n',
            '<input type="hidden" name="countryCode" value="', self.request['countryCode'],  '" />\n',
            '<input type="hidden" name="currencyCode" value="', self.request['currencyCode'],  '" />\n',
            '<input type="hidden" name="customerAddress" value="', self.request['customerAddress'],  '" />\n',
            '<input type="hidden" name="customerName" value="', self.request['customerName'],  '" />\n',
            '<input type="hidden" name="customerPhone" value="', self.request['customerPhone'],  '" />\n',
            '<input type="hidden" name="customerPostCode" value="', self.request['customerPostCode'],  '" />\n',
            '<input type="hidden" name="merchantID" value="', self.id + '" />\n',
            '<input type="hidden" name="orderRef" value="', self.request['orderRef'],  '" />\n',
            '<input type="hidden" name="signature" value="', self.signature, '" />\n',
            '<input type="hidden" name="type" value="1" />\n',
            '<input  type="submit" value="Pay Now">\n',
            '</form>\n'
        ]

        self.assertEqual(response, ''.join(map(str, expect)))

if __name__ == '__main__':
    import unittest
    unittest.main()
