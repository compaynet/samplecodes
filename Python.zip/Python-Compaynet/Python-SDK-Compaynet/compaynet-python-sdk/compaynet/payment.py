"""Compaynet Payment Gateway SDK.
"""

from collections import OrderedDict
from hashlib import sha512
from urllib import urlencode
from urlparse import parse_qs
from time import time

import cgi
import re
import requests


class Gateway(object):

    """Class to communicate with Payment Gateway.
    """

    RC_SUCCESS = 0                  # Transaction successful reponse code
    RC_DO_NOT_HONOR = 5             # Transaction declined reponse code
    RC_NO_REASON_TO_DECLINE = 85    # Verification successful reponse code

    RC_3DS_AUTHENTICATION_REQUIRED = 0x1010A

    REMOVE_REQUEST_FIELDS = [
        'directUrl',
        'hostedUrl',
        'merchantAlias',
        'merchantID2',
        'merchantSecret',
        'responseCode',
        'responseMessage',
        'responseStatus',
        'signature',
        'state',
    ]

    def __init__(self, gatewayUrl, merchantID, merchantSecret, merchantPwd=None, proxies=None):

        """Configure the Payment Gateway interface.

        Args:
            gatewayUrl      Gateway API Endpoint (Direct or Hosted)
            merchantID      Merchant Account Id or Alias
            merchantSecret  Secret for above Merchant Account
            merchantPwd     Password for above Merchant Account
            proxies         Proxy connection(s) if required
                            (e.g. {'https': 'https://www.proxy.com:3128'})
        """

        self.gatewayUrl = gatewayUrl
        self.merchantID = merchantID
        self.merchantSecret = merchantSecret
        self.merchantPwd = merchantPwd
        self.proxies = proxies

    def directRequest(self, request, **options):

        """Send request to Gateway using HTTP Direct API.

        The method will send a request to the Gateway using the HTTP Direct API.

        The request will use the following Gateway properties unless alternative
        values are provided in the request:
            'directUrl'      - Gateway Direct API Endpoint
            'merchantID'     - Merchant Account Id or Alias
            'merchantPwd'    - Merchant Account Password
            'merchantSecret' - Merchant Account Secret

        The method will sign the request and also check the signature on any
        response.

        The method will throw an exception if it is unable to send the request
        or receive the response.

        The method does not attempt to validate any request fields.

        The method will attempt to send the request using the Requests HTTP
        library for Python.

        Args:
            request     request data
            options     options
        Returns:
            verified response data
        Raises:
            ValueError          invalid request data
            RequestException    communications failure
        """

        if 'directUrl' in request:
            directUrl = request['directUrl']
        else:
            directUrl = self.gatewayUrl

        if 'merchantSecret' in request:
            secret = request['merchantSecret']
        else:
            secret = self.merchantSecret

        if not 'transactionUnique' in request:
            request['transactionUnique'] = self.uniqid()

        _request = self.prepareRequest(request, **options)

        if secret:
            _request['signature'] = self.sign(_request, secret)

        _response = requests.post(directUrl, _request, proxies=self.proxies)

        _response.raise_for_status()

        data = parse_qs(_response.text)

        response = {
            name: value if len(value) > 1 else value[0] for name, value in data.items()
        }

        return self.verifyResponse(response, secret)

    def hostedRequest(self, request, **options):

        """Send request to Gateway using HTTP Hosted API.

        The method will send a request to the Gateway using the HTTP Hosted API.

        The request will use the following Gateway properties unless alternative
        values are provided in the request:
            'hostedUrl'      - Gateway Hosted API Endpoint
            'merchantID'     - Merchant Account Id or Alias
            'merchantPwd'    - Merchant Account Password
            'merchantSecret' - Merchant Account Secret

        The method accepts the following options:
            'formAttrs'      - HTML form attributes
            'submitAttrs'    - HTML submit button attributes
            'submitImage'    - Image to use as the Submit button
            'submitHtml'     - HTML to show on the Submit button
            'submitText'     - Text to show on the Submit button

        'submitImage', 'submitHtml' and 'submitText' are mutually exclusive
        options and will be checked for in that order. If none are provided
        the submitText='Pay Now' is assumed.

        The method will sign the request; partial signing will be used to allow
        for submit button images et cetera.

        The method returns the HTML fragment that needs including in order to
        send the request.

        The method does not attempt to validate any request fields.

        Args:
            request     request data
            options     options
        Returns:
            request HTML form
        Raises:
            ValueError  invalid request data
        """

        if 'hostedUrl' in request:
            hostedUrl = request['hostedUrl']
        else:
            hostedUrl = self.gatewayUrl

        if 'merchantSecret' in request:
            secret = request['merchantSecret']
        else:
            secret = self.merchantSecret

        _request = self.prepareRequest(request, **options)

        if secret:
            _request['signature'] = self.sign(_request, secret, partial=True)

        form = '<form method="post" '

        if 'formAttrs' in options:
            form += options['formAttrs']

        form += ' action="' + htmlencode(hostedUrl) + '">\n'

        for name in sorted(_request.keys()):
            form += self.fieldToHtml(name, str(_request[name]))

        if 'submitHtml' in options:
            form += '<button type="submit" '
        else:
            form += '<input '

        if 'submitAttrs' in options:
            form += options['submitAttrs']

        if 'submitImage' in options:
            form += ' type="image" src="' + htmlencode(options['submitImage']) + '">\n'
        elif 'submitHtml' in options:
            form += '>' + options['submitHtml'] + '</button>\n'
        elif 'submitText' in options:
            form += ' type="submit" value="' + htmlencode(options['submitText']) + '">\n'
        else:
            form += ' type="submit" value="Pay Now">\n'

        form += '</form>\n'

        return form

    def prepareRequest(self, request, **options):

        """Prepare a request for sending to the Gateway.

        The method will insert the following configuration properties into
        the request if they are not already present:
            'merchantID'     - Merchant Account Id or Alias
            'merchantPwd'    - Merchant Account Password (if provided)

        The method will throw an exception if the request doesn't contain
        an 'action' element or a 'merchantID' element (and none could be
        inserted).

        The method does not attempt to validate any request fields.

        Args:
            request     request data
            options     options
        Returns:
            request data ready for sending
        Raises:
            ValueError  invalid request data
        """

        if 'action' not in request:
            raise ValueError("Request must contain an 'action'.")

        _request = request.copy()

        if 'merchantID' not in _request:
            _request['merchantID'] = self.merchantID

        if 'merchantPwd' not in _request and self.merchantPwd:
            _request['merchantPwd'] = self.merchantPwd

        if not _request['merchantID']:
            raise ValueError("Merchant ID or Alias must be provided.")

        for name in self.REMOVE_REQUEST_FIELDS:
            if name in _request:
                del _request[name]

        return _request

    def verifyResponse(self, response, secret=None):

        """Verify the response from the Gateway.

        This method will verify that the response is present, contains a
        response code and is correctly signed.

        If the response is invalid then an exception will be thrown.

        Any signature is removed from the passed response.

        Args:
            response    response to verify
            secret      secret to use in signing
        Returns:
            verified response data
        Raises:
            ValueError  invalid response data
        """

        if not 'responseCode' in response:
            raise ValueError('Invalid response from Payment Gateway')

        if secret is None:
            secret = self.merchantSecret

        _response = response.copy()

        if 'signature' in _response:

            signature = _response.pop('signature')

            if '|' in signature:
                signature, partial = signature.split('|', 1)
            else:
                partial = None

        else:
            signature = None
            partial = None

        if secret is None and signature:
            # Signature present when not expected (Gateway has a secret but we don't)
            raise ValueError('Incorrectly signed response from Payment Gateway (1)')

        if secret and signature is None:
            # Signature missing when one expected (we have a secret but the Gateway doesn't)
            raise ValueError('Incorrectly signed response from Payment Gateway (2)')

        if secret and self.sign(_response, secret, partial) != signature:
            # Signature mismatch
            raise ValueError('Incorrectly signed response from Payment Gateway')

        _response['responseCode'] = int(_response['responseCode'])

        return _response

    def sign(self, data, secret=None, partial=None):

        """Sign the given array of data.

        This method will return the correct signature for the data array.

        If the secret is not provided then merchantSecret is used.

        The partial parameter is used to indicate that the signature should
        be marked as 'partial' and can take three possible value types as
        follows:
            boolean  - sign with all fields
            string   - comma separated list of field names to sign
            array    - array of field names to sign

        Args:
            data    data to sign
            secret  secret to use in signing
            partial partial signing
        Returns:
            signature
        """

        if secret is None:
            secret = self.merchantSecret

        _data = OrderedDict(sorted(data.items()))

        if partial:

            if isinstance(partial, basestring):
                partial = partial.split(',')

            if isinstance(partial, list) or isinstance(partial, tuple):
                for name in _data.keys():
                    if name not in partial:
                        del _data[name]

            partial = ','.join(sorted(_data))

        message = re.sub(r'%0D%0A|%0A%0D|%0D', r'%0A', urlencode(_data), flags=re.IGNORECASE)

        signature = sha512(message + secret).hexdigest()

        if partial:
            return signature + '|' + partial

        return signature

    def fieldToHtml(self, name, value):

        """Return the field name and value as HTML input tags.

        The method will return a string containing one or more HTML <input
        type="hidden"> tags which can be used to store the name and value.

        Args:
            name    field name
            value   field value
        Returns:
            HTML containing <INPUT> tags
        """

        if value == '':
            return ''

        name = htmlencode(name)
        value = htmlencode(value)

        return '<input type="hidden" name="{}" value="{}" />\n'.format(name, value)

    def uniqid(self, prefix = ''):
        return prefix + hex(int(time()))[2:10] + hex(int(time()*1000000) % 0x100000)[2:7]

def htmlencode(s):

    """Convert all applicable characters to HTML entities.

    Args:
        s   input string
    Returns:
        the encoded string
    """

    return cgi.escape(str(s)).encode('ascii', 'xmlcharrefreplace')
