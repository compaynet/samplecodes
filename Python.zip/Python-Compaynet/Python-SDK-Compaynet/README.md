Compaynet Python SDK
==============

Overview
---------

Python SDK that can be used to allow the use of the Compaynet payment gateway within Python applications.

Requirements
------------

The minimum requirement for this SDK is Python 2.7
