python-direct-sample
====================

Sample code to take credit card and debit card payments with the Compaynet Payment Gateway with Python.
