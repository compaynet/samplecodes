import requests, collections, hashlib, urllib

__author__ = 'Compaynet'

DIRECT_ENDPOINT = 'https://csgateway.compaynet.com/direct/'

PRE_SHARED_KEY = 'Excuse8Boil48Fleet'

req = {
    'merchantID': 108896,
    'action': 'SALE',
    'type' : 1,
    'currencyCode' : 826,
    'countryCode' : 826,
    'amount' : 1000,
    'cardNumber' : 4929421234600821,
    'cardExpiryMonth' : 12,
    'cardExpiryYear' : 15,
    'cardCVV' : 356,
    'customerName' : "John Smith",
    'customerPhone' : "+44 (0) 8450099575",
    'customerAddress' : "6347 Test Card Street",
    'customerPostCode' : "17T ST8"
}

# sort the request by key
sig =  collections.OrderedDict(sorted(req.items()))

# make a http string aranged by key and SHA512 it
req['signature'] = hashlib.sha512(urllib.urlencode(sig) + PRE_SHARED_KEY).hexdigest()

# do the request
res = requests.post(DIRECT_ENDPOINT, req)

print(res.text, req)
