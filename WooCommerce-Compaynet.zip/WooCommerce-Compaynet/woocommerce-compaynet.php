<?php
/*
Plugin Name: WooCommerce Compaynet
Plugin URI: http://woothemes.com/woocommerce/
Description: Provides a Compaynet gateway for WooCommerce
Version: 1.2
Author: Compaynet
Author URI: http://www.compaynet.com/
License: GPL2
*/

/*  Copyright 2017  Compaynet  (support@compaynet.com)

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License, version 2, as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/

/**
 * Initialise Compaynet Gateway
 **/
add_action('plugins_loaded', 'init_compaynet', 0);

function init_compaynet() {

	if (!class_exists('WC_Payment_Gateway')) {
		return;
	}

	add_filter('plugin_action_links', 'CPN_add_action_plugin', 10, 5);

	include( 'classes/compaynet.php' );

	add_filter('woocommerce_payment_gateways', 'add_compaynet_hosted' );

}

function CPN_add_action_plugin($actions, $plugin_file)
{
	static $plugin;

	if (!isset($plugin))
	{
		$plugin = plugin_basename(__FILE__);
	}

	if ($plugin == $plugin_file)
	{
		$actions = array_merge(array('settings' => '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=wc_compaynet_hosted') . '">' . __('Settings', 'General') . '</a>'), $actions);
	}

	return $actions;
}

function add_compaynet_hosted($methods) {
	$methods[] = 'WC_Compaynet_Hosted';
	return $methods;
}
