Direct-CSharp-Sample
====================

example code for Csharp integrations to Compaynet Direct
