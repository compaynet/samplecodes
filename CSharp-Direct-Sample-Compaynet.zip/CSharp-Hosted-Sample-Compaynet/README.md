Hosted-Csharp-Sample
====================

example code for Csharp integrations to Compaynet Hosted
