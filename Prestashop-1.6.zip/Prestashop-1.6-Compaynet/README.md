Compatibility
=================================

Compatible with Version 1.5 and 1.6 only

Hosted Form Module for PrestaShop
=================================


**Step 1:**

Copy the contents of the httpdocs folder into your root PrestaShop directory. If you
are asked if you want to replace any existing files, click “Yes”.

**Step 2:**

Log in to the Admin area of PrestaShop, then from the left menu, click Modules. Next, from the 'Module List', select 'Payments and Gateways'. From the list, select Compaynet and click the green 'install' button on the right.

**Step 3:**

From here, enter your Merchant ID, Currency Code, Country ID and Passphrase. In the 'Frontend' box, enter a sentence asking your customer to pay with Compaynet, i.e. "Process payments with Compaynet".
NOTE: The Frontend box MUST be filled in for the module to work. Click Update Settings.
