<?php
/**
 * 2017 Compaynet
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 *  @author    Compaynet <support@compaynet.com>
 *  @copyright 2017 Compaynet Ltd
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

class Compaynet extends PaymentModule
{
    public function __construct()
    {
        $this->bootstrap   = true;
        $this->name        = 'compaynet';
        $this->tab         = 'payments_gateways';
        $this->version     = '2.0.1';
        $this->author      = 'Compaynet';
        $this->controllers = array( 'payment', 'validation' );

        parent::__construct();

        $this->displayName            = 'Compaynet Hosted Form';
        $this->description            = $this->l('Process payments with Compaynet');
        $this->ps_versions_compliancy = array( 'min' => '1.5', 'max' => _PS_VERSION_ );
    }

    /*
     * install registers hooks now
     */
    public function install()
    {
        // if prestashop multi store is active, change context to global
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }

        if (!parent::install() || !$this->registerHook('displayPayment') ||
            !$this->registerHook('displayPaymentReturn') || !$this->registerHook('header')
        ) {
            return false;
        }

        return true;

    }

    public function uninstall()
    {
        Configuration::deleteByName('COMPAYNET_MERCHANT_ID');
        Configuration::deleteByName('COMPAYNET_CURRENCY_ID');
        Configuration::deleteByName('COMPAYNET_COUNTRY_ID');
        Configuration::deleteByName('COMPAYNET_FRONTEND');
        Configuration::deleteByName('COMPAYNET_MERCHANT_PASSPHRASE');


        return parent::uninstall();
    }

    public function hookOrderConfirmation($params)
    {


        if ($params['objOrder']->module != $this->name) {
            return "";
        }

        if ($params['objOrder']->getCurrentState() != _PS_OS_ERROR_) {
            $this->smarty->assign(
                array(
                    'status'   => 'ok',
                    'id_order' => (int)$params['objOrder']->id
                )
            );
        } else {
            $this->smarty->assign('status', 'failed');
        }

        return $this->display(__FILE__, 'hookorderconfirmation.tpl');
    }

    public function getContent()
    {

        $output = null;

        if (Tools::isSubmit('submit' . $this->name)) {
            Configuration::updateValue('COMPAYNET_MERCHANT_ID', Tools::getvalue('compaynet_merchant_id'));
            Configuration::updateValue('COMPAYNET_CURRENCY_ID', Tools::getvalue('compaynet_currency_id'));
            Configuration::updateValue('COMPAYNET_COUNTRY_ID', Tools::getvalue('compaynet_country_id'));
            Configuration::updateValue('COMPAYNET_FRONTEND', Tools::getvalue('compaynet_frontend'));
            Configuration::updateValue('COMPAYNET_MERCHANT_PASSPHRASE', Tools::getvalue('compaynet_passphrase'));
            $output .= $this->displayConfirmation($this->l('Settings updated'));

        }

        return $output . $this->displayForm();
    }

    public function displayForm()
    {
        // Get default language
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        $fields_form  = array();
        // Init Fields form array
        $fields_form[0]['form'] = array(
            'legend' => array(
                'title' => $this->l('Compaynet Settings'),
            ),
            'input'  => array(
                array(
                    'type'     => 'text',
                    'label'    => $this->l('Merchant ID'),
                    'name'     => 'compaynet_merchant_id',
                    'class'    => 'fixed-width-md',
                    'required' => true
                ),
                array(
                    'type'     => 'text',
                    'label'    => $this->l('Currency Code'),
                    'name'     => 'compaynet_currency_id',
                    'class'    => 'fixed-width-xs',
                    'required' => true
                ),
                array(
                    'type'     => 'text',
                    'label'    => $this->l('Country Code'),
                    'name'     => 'compaynet_country_id',
                    'class'    => 'fixed-width-xs',
                    'required' => true
                ),
                array(
                    'type'     => 'text',
                    'label'    => $this->l('Passphrase / Shared Secret'),
                    'name'     => 'compaynet_passphrase',
                    'class'    => 'fixed-width-xl',
                    'required' => true
                ),
                array(
                    'type'     => 'text',
                    'label'    => $this->l('Frontend Text'),
                    'name'     => 'compaynet_frontend',
                    'class'    => 'fixed-width-xl',
                    'required' => true
                )
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'button'
            )
        );


        $helper = new HelperFormCore();

        // Module, token and currentIndex
        $helper->module          = $this;
        $helper->name_controller = $this->name;
        $helper->token           = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex    = AdminController::$currentIndex . '&configure=' . $this->name;

        // Language
        $helper->default_form_language    = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;

        // Title and toolbar
        $helper->title          = $this->displayName;
        $helper->show_toolbar   = true; // false -> remove toolbar
        $helper->toolbar_scroll = true; // yes - > Toolbar is always visible on the top of the screen.
        $helper->submit_action  = 'submit' . $this->name;
        $helper->toolbar_btn    = array(
            'save' =>
                array(
                    'desc' => $this->l('Save'),
                    'href' => AdminController::$currentIndex . '&configure=' . $this->name . '&save' . $this->name .
                              '&token=' . Tools::getAdminTokenLite('AdminModules'),
                ),
            'back' => array(
                'href' => AdminController::$currentIndex . '&token=' . Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->l('Back to list')
            )
        );

        // Load current values
        $helper->fields_value['compaynet_merchant_id'] = Configuration::get('COMPAYNET_MERCHANT_ID');
        $helper->fields_value['compaynet_currency_id'] = Configuration::get('COMPAYNET_CURRENCY_ID');
        $helper->fields_value['compaynet_country_id']  = Configuration::get('COMPAYNET_COUNTRY_ID');
        $helper->fields_value['compaynet_passphrase']  = Configuration::get('COMPAYNET_MERCHANT_PASSPHRASE');
        $helper->fields_value['compaynet_frontend']    = Configuration::get('COMPAYNET_FRONTEND');

        return $helper->generateForm($fields_form);
    }

    public function hookPayment($params)
    {

        if (!$this->active) {
            return;
        }

        $this->smarty->assign(
            array(
                'frontend'      => Configuration::get('COMPAYNET_FRONTEND'),
                'this_path'     => $this->_path,
                'this_path_bw'  => $this->_path,
                'this_path_ssl' => Tools::getShopDomainSsl(true, true) . __PS_BASE_URI__ . 'modules/' . $this->name .
                                   '/'
            )
        );

        return $this->display(__FILE__, 'payment.tpl');

    }

    public function hookPaymentReturn($params)
    {

        if (!$this->active) {
            return;
        }

        if ($params['objOrder']->module != $this->name) {
            return "";
        }

        if ($params['objOrder']->getCurrentState() != _PS_OS_ERROR_) {
            $this->smarty->assign(
                array(
                    'status'   => 'ok',
                    'id_order' => (int)$params['objOrder']->id
                )
            );
        } else {
            $this->smarty->assign('status', 'failed');
        }

        return $this->display(__FILE__, 'payment_confirmation.tpl');
    }

    /**
     * adds our css file to the header
     */
    public function hookHeader()
    {
        if (Configuration::get('PS_CATALOG_MODE')) {
            return;
        }

        $this->context->controller->addCSS(( $this->_path ) . 'views/css/compaynet.css', 'all');

    }

    public function createCompaynetSignature(array $data, $key, $algo = null)
    {

        if ($algo === null) {
            $algo = 'SHA512';
        }

        ksort($data);

        // Create the URL encoded signature string
        $ret = http_build_query($data, '', '&');

        // Normalise all line endings (CRNL|NLCR|NL|CR) to just NL (%0A)
        $ret = preg_replace('/%0D%0A|%0A%0D|%0A|%0D/i', '%0A', $ret);

        // Hash the signature string and the key together
        $ret = hash($algo, $ret . $key);

        // Prefix the algorithm if not the default
        if ($algo !== 'SHA512') {
            $ret = '{' . $algo . '}' . $ret;
        }

        return $ret;
    }
}
