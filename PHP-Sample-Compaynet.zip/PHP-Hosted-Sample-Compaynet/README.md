PHP-Hosted-Sample
=================

Sample code to take card payments via the Compaynet Hosted Form
